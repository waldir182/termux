import Tab from "./js/Tab.js";
import Iframe from "./js/Iframe.js";

let openedTabs = [];
const btnAddIframe = document.querySelector(".tab-add");
const contenedorTabs = document.querySelector(".tabs");
const contenedorIframes = document.querySelector(".iframe-capa");

function addNewTab(e) {
  let tabs = document.querySelectorAll(".tab-btn");
  let lastId;
  if (tabs.length >= 1) lastId = Number(tabs[tabs.length - 1].getAttribute("data-id")) + 1;
  else lastId = 1;
  let url = "http://"+location.host+"/newpage.html";
  let miIframe = new Iframe(lastId, url);
  let tab = new Tab(lastId, url);
  contenedorIframes.appendChild(miIframe.iframe);
  contenedorTabs.insertBefore(tab.btnClose, btnAddIframe);
  openedTabs.push({
    id: lastId,
    tab,
    miIframe,
  });
}
btnAddIframe.addEventListener("click", addNewTab);

// Eventos de un Tab button
document.addEventListener("click", (e) => {
  if (e.target.matches(".tab-btn") || e.target.matches(".tab-btn i")) {
    let id =
      e.target.getAttribute("data-id") ||
      e.target.parentNode.getAttribute("data-id");
    openedTabs.forEach((pro) => {
      if (pro.id == id) {
        pro.tab.onclick();
      }
    });
  }

  if (e.target.matches(".tab-btn span")) {
    let newArray = [];
    let id = e.target.parentNode.getAttribute("data-id");
    openedTabs.forEach((pro, index) => {
      if (pro.id === Number(id)) {
        pro.tab.delete();
      } else {
        newArray.push(pro);
      }
    });
    openedTabs = newArray;
  }
});

// Agregar un iframe al cargar la pagina
document.addEventListener("DOMContentLoaded", () => {
  addNewTab();
});
