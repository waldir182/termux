// Toggle al zona de salida
const closeZone = document.querySelector(".close-zone");
const outZone = document.querySelector(".output-zone");
let ts = 0, tm = 0, te = 0, sw = screen.width;

document.addEventListener('touchstart', e => {
  ts = e.touches[0].screenX;
})
document.addEventListener('touchmove', e => {
  if(ts > sw - 8) {
    tm = e.touches[0].screenX;
    let sob = sw - tm;
    let dis = 460 - sob ;
    if(dis < 0) return;
    outZone.style.right = -dis + "px";
    //closeZone.innerHTML=`${tm}<br>${dis}<br> | ${sw}`;
    closeZone.classList.add("active");
  }
})
document.addEventListener('touchend', e => {
  te = e.changedTouches[0].screenX;
  if((ts > sw - 1) && te < sw - 5) {
    outZone.style.right = 0;
    closeZone.classList.add("active");
  } else {
    if(ts > sw - 8) {
      outZone.style.right = -460+"px";
      closeZone.classList.remove("active");
    }
  } 
  ts = 0; tm = 0; te = 0;
})


document.addEventListener("click", (e) => {
  if (e.target.matches(".close-zone")) {
    outZone.style.right = -460+"px";
    closeZone.classList.toggle("active");
  }
  if (e.target.matches("#external") || e.target.matches("#external *")) {
    let t = document.querySelector(".tab-btn.active");
    let link = t.querySelector("i").textContent;
    window.open(link, "_blank", "", false)
  }
  if (e.target.matches("#btn-theme") || e.target.matches("#btn-theme *")) {
    outZone.classList.toggle("light");
  }
});

// Funciones de Botones
const iframeLive = document.querySelector(".iframe-live");
const input = document.getElementById("outLink");

const btnPlayLive = document.getElementById("play-live");
const btnBrowser = document.getElementById("browser");

function redirect(e, url) {
  let btnActive = document.querySelector(".tab-btn.active");
  let iframeActive = document.getElementById(
    `iframe-${btnActive.getAttribute("data-id")}`
  );
  iframeActive.src = url || iframeActive.src;
  input.value = url || iframeActive.src;
  btnActive.querySelector("i").textContent = url || iframeActive.src;
}

btnPlayLive.addEventListener("click", (e) => {
  let url = "http://localhost:8000";
  redirect(e, url);
});
btnBrowser.addEventListener("click", (e) => {
  let url = "https://www.bing.com";
  redirect(e, url);
});

const btnReload = document.getElementById("reloader");
btnReload.addEventListener("click", (e) => {
  redirect(e);
});

input.addEventListener("keyup", (e) => {
  if (e.keyCode === 13) {
    redirect(e, e.target.value);
  }
});
